module RedmineGithubHook
  VERSION = "2.2.0"
end
